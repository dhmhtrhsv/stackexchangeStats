
# StackexchangeStats

## Installation
The specific package was tested using python 2.7.15 both in Windows 10 and Ubuntu 18.10.

#### Windows
Download the file in the zip format and save it e.g. in the Downloads folder.
Open a Command Prompt in a new folder and type: 
```sh
pip install C:\Users\user\Downloads\StackexchangeStats.zip
```
where in the place of the user, type your username. If you save it in another location, edit the directory respectively.

#### Ubuntu
Download the file in the zip format and save it e.g. in the Downloads folder.
Open a Terminal in a new folder and type: 
```sh
pip install /home/user/Downloads/StackexchangeStats.zip
```
where in the place of the user, type your username. If you save it in another location, edit the directory respectively.

## How to run the application

#### Windows, Ubuntu
Type in the same Command Prompt (Windows) or in the same Terminal (Ubuntu):
```sh
python -m stackexchangeStats.stackexchangeStats stats --since 2016-06-02-10-00-00 --until 2016-06-02-11-00-00 --output-format json
```

The date\time must be in the YYYY-MM-DD-HH-MM-SS format.
The output format can be either html or json, depending on what you type.
The stats, --since date, --until date are required to by typed, while the --output-format and the argument after that, is optional (the default value is json), so you could also type:
```sh
python -m stackexchangeStats.stackexchangeStats stats --since 2016-06-02-10-00-00 --until 2016-06-02-11-00-00
```
I made the hypothesis that the user will type correct date/time ranges and that there will be enough (accepted) answers, because there aren't any checks e.g. division by zero, or if the user firstly types a date that is later than the second date.